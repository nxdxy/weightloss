#!/bin/bash

# AI Fitness Pal 快速部署脚本

set -e

DOMAIN=${1:-localhost}

echo "🚀 开始快速部署 AI Fitness Pal..."
echo "域名: $DOMAIN"

# 检查 Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker 未安装，请先安装 Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose 未安装，请先安装 Docker Compose"
    exit 1
fi

# 恢复数据
if [ -f "data/fitness_pal.db" ]; then
    echo "📁 恢复数据库..."
    mkdir -p backend
    cp data/fitness_pal.db backend/
fi

if [ -d "uploads" ]; then
    echo "📁 恢复上传文件..."
    mkdir -p backend
    cp -r uploads backend/
fi

# 设置权限
chmod +x scripts/*.sh
chmod +x deploy.sh

# 部署
echo "🔨 开始部署..."
./deploy.sh "$DOMAIN"

echo "✅ 部署完成！"
echo "🌐 访问地址: http://$DOMAIN"
